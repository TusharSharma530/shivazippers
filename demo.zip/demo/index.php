<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
     <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
     <link rel="stylesheet" href="slick/slick.css">
    <link rel="stylesheet" href="slick/slick-theme.css">
    <link href="style.css" rel="stylesheet">
    <script src="slick/slick.min.js" defer></script>
    <script src="js/script.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="headerpart">
    <div class="container">
    <div class="topcontainer">   
    
        <div class="logo-section">
                <div class="logo-section">
                    <!-- <a href="javascript:"> -->
                 <a href="javascript:">   <img src="assets/logoimg.png"> </a>
                    <div class="text-section">
                       <a href="javascript:"> <h1>Dr. Paridhi Chaudhary</h1> 

                        <p>
                            Obstetrician & Gynecologist, Laparoscopic
                            <br>
                            Surgeon and Infertility Specialist
                        </p>
                     </a>
                    </div>

                </div>
        </div>

        <div class="contact-section">
                    <div class="contact-image">
                        <div class="contact-imageinner">
                                <i class="bi bi-envelope headericon"></i>
                        </div>
                        <div class="contact-text">
                          <a href="mailto:drparidhichaudhary@gmail.com">  <span class="contact-label">  Mail Us</span> 
                            <p>drparidhichaudhary@gmail.com</p> </a>
                        </div>
                    </div>
                    <div class="contact-heading">
                        <div class="contact-imageinnerphone">
                                <i class="bi bi-telephone headericon"></i>
                         </div>
                         <div class="contact-text">
                        <a href="tel:9286197331"><span class="contact-labelcontact">Contact Us</span>
                            <p> +91-9286197331,  +91-01214567142</p> </a>
                         </div>
                       
                    </div>
                </div>
    </div>  

</div>
</div>

</div>

<div class="header">
    <div class="headercontainer">
        
            <div class="container">
                <div class =" headerconti">
                    <div class="headerinner">
                        <a href="javascript:"> Home</a>
                            <a href="javascript:"> About</a>
                            <a href="javascript:"> Services</a>
                        <a href="javascript:"> Gallery</a>
                        <a href="javascript:"> Contact</a>
                    </div>
                    <div class="appointbtn">
                        <button class="submitbtn">Book An Appointment</button>
                    </div>
                </div>    
             </div>
    </div>
</div>

<div class="banner-section">
    
        <div class="slider" data-slides-desktop="1" data-slides-mobile="1">
            <img src="assets/drparidhi.webp">
            <img src="assets/banner6.webp">
            <img src="assets/banner5.webp">
            <img src="assets/banner4.webp">
        </div>
   
</div>

<div class="about-section">
    <div class="aboutcontainer">
        <div class="container">
              <div class="aboutinner">
                        <div class="abouttext paragraphheading">
                                <h1 class="tagheading">Dr Paridhi Chaudhary</h1>
                                <h2>Meet Our Gynaecologist in Meerut <br>MBBS,MS,DNB</h2>
                                <p>I believe Obstetrics & Gynecology is an important and sensitive field of medicine that requires dedication, empathy, and compassion. Every woman deserves to be heard, understood, and treated with respect. My goal is to provide a comfortable environment where patients can openly discuss their concerns and receive personalized care according to their needs.</p>
                                <p>My approach focuses on supporting women through every stage of life, from routine gynecological care and pregnancy to reproductive health and menopause. I strive to provide clear guidance, compassionate support, and quality medical care while helping every patient make informed decisions about her health and well-being.</p>
                            <div class="aboutbuttoncontainer">
                                <button class="aboutbutton">Know More</button>
                                <a href="javascript:">Helpline ! : +91-9286197331, 01214567142</a>
                            </div>          
                        </div>
                            <div class="aboutimage">
                                <img src="assets/drparidhiaboutus.webp">
                            </div>
                 </div>
            </div>
    </div> 
</div>    

<div class="servicesection">
    <div class="container">
        <div class="serviceinner paragraphheading">
            <h1 class="serviceheading tagheading">Condition We Treat</h1>
            <h2>Conditions Treated By Dr.Paridhi Chaudhary - Gynaecologist in Meerut</h2>
        </div>
        <div class="slider servicecardcontainer" data-slides-desktop="4" data-slides-mobile="1">
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/periodrelated.webp">
                </figure>
                <h3>Pregnancy Care</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Infertility Problem</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Period related problem</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Cancer Screening</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/periodrelated.webp" class="servicecardimg">
                </figure>
                <h3>Laparascopic</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            
            
</div>  
    </div>
</div>
<div class="gallery-section">
    <div class="container">
        <div class="headgallery paragraphheading">
                <h1 class="gallerytag tagheading">Our Clinic </h1>
                <h2 class="galleryhead ">Gallery</h2>
        </div>
        <div class="gallerycontainer">
            <div class="slider galeryimg"data-slides-desktop="4" data-slides-mobile="1">
          
                <img src="assets/galleryimage.jpeg">
                <img src="assets/galleryimage2.jpeg">
                <img src="assets/galleryimage3.jpeg">
                <img src="assets/galleryimage4.jpeg">
         
            </div>    
        </div>
    </div>
</div>

<div class="mycommitmentsection">
    <div class="container">
     <div class="innercontainer">
        <div>
            <img src = "assets/commitment.png">
        </div>
            <div class="commitmentinnerpara paragraphheading">
                <h1 class="tagheading"> My Commitment </h1>
                <h2>Commitment To Every Patient's Health & Well-Being </h2>
                <p>I am committed to providing compassionate, ethical, and evidence-based gynecological care to every woman who walks into my clinic. From routine consultations to complex treatments, every patient receives complete attention, clear guidance, and honest advice at every step.</p>
                <p>.My priority is to build a comfortable and trusting relationship where women can openly discuss their health concerns without hesitation and receive personalized care that suits their individual needs and stage of life.</p>
            </div>
            
        </div>
</div>
    </div>
</div>

<div class=bookappointmentcontainer>
    <div class="container">
    <h1 class = "bookhead"> Facing Gynae Concerns? Get Expert Help From <br> Dr. Paridhi Chaudhary </h1>
            <div class="callus">
                        <div class="callinner sectionpara">
                            <div>
                                <i class="bi bi-telephone bookicon"></i>
                             </div>
                             <div>
                                <a href="javascript:">
                                <h1 class="head"> Call Us :</h1>
                                <p>+91-9286197331 , 01214567142</p>
                               </a>
                              </div>   
                        </div>
                        <div class="callinneremail sectionpara">
                            <div>
                                 <i class="bi bi-envelope-fill bookicon"></i>
                                
                            </div>
                               <div>
                                <a href="javascript:">
                                <h1 class="head"> E-mail Us :</h1>
                                <p>drparidhichaudhary@gmail.com</p> </a>
                               </div>
                        </div>
               
                        <div class="visitus sectionpara">
                            <div>
                                <i class="bi bi-geo-alt bookicon"></i>
                             </div>
                             <div>
                            <h1 class="head">Visit Us :</h1>
                            <p>Shop No,6,7,RPG Galleria GP Pocket,Ganga Nagar, <br>Meerut,Uttar Pradesh-250001</p>
                           </div>
                        </div>
                   <a href="javascript:"> <button class="bookbtn">Book an Appointment</button></a>
        </div>
    </div>
</div>

    <div class="symptomscontainer">
        <div class="container">
            <div class="paragraphheading">
            <h1 class="tagheading symtag">Symptoms</h1>
            <h2 class="symptoms">
                What are the Symptoms of Gynaecological Diseases
            </h2>
            <p class="symptomsintro">
                Gynecological conditions can often go unnoticed in the early stages. Recognizing the warning signs early is key to timely diagnosis and effective treatment. If you're experiencing any of the following symptoms, it may indicate an underlying gynecological issue:
            </p>
          </div>
            
            <div class="litags">  
                       <ul class= "symplomeli">
                            <li>
                                Missed menstrual period
                            </li>
                            <li>
                               Irregular Period
                            </li>
                           
                             <li>
                                Pain or discomfort during intercourse
                            </li>
                             <li>
                                Vaginal Itching
                            </li>
                             <li>
                                Heavy menstrual bleeding
                            </li>
                             <li>
                                Pain or pressure in your Pelvis <br>that differ from menstrual cramps
                            </li> 
                            <li>
                                Excessive bloating
                           </li>
                           <li>
                            Breast Changes
                           </li>

                        </ul>   
            </div>
        
        </div>
    </div>    
<div class="testinomialcontainer">
        <div class="container">
            <div >
           <div class="paragraphheading">
            <h1 class="tagheading testimon">Testimonials</h1>
            <h2 class="symptoms tagheading">what our patents says about us </h2>
            <p class="serviceheadingh2">Experience shared by patents about their core and consultation with dr paridhi chaudhary </p>
            </div>
            <div class="testinomialcards slider"data-slides-desktop="3" data-slides-mobile="3">
              <div class="testinomialinner ">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Excellent </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
              <div class="testinomialinner">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Caring </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
               <div class="testinomialinner">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Smart </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
              <div class="testinomialinner">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Caring </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
            </div>
</div>
        </div>
</div>
<div class="latestblogcontainer">
            <div class="container">
                <div class="paragraphheading">
                    <h1 class="tagheading article">Health Article </h1>
                    <h2 class="serviceheadingh2">Latest Blogs</h2>
                    <p class="blogpara"> Explore helpful information ,expert guidance , women's healthcare tips from
                        dr paridhary .
                    </p>
                </div>
                <div class="slider "data-slides-desktop="3" data-slides-mobile="3">
                    <div class="blogscontainer">
                        <img src = "assets/pregnancycare.webp">
                        <div class="pregpara">
                            <h1>Pregnancy Care</h1>
                            <h2>Tips for health Pregnancy </h2>
                            <p>Learn about prenanral checkup,healthy habits nutrition and important precautions during pregnancy </p>
                             <a href="javascript:">
                        <button class="readmorebutton">Read More -></button></a>
                        </div>
    
                    </div>
                    <div class="blogscontainer">
                        <img src = "assets/pregnancycare.webp">
                        <div class="pregpara">
                            <h1 >Pregnancy Care</h1>
                            <h2 >Tips for health Pregnancy </h2>
                            <p >Learn about prenanral checkup,healthy habits nutrition and important precautions during pregnancy </p>
                             <a href="javascript:">
                        <button class="readmorebutton">Read More -></button></a>
                        </div>
                       
                    </div>
                    <div class="blogscontainer">
                        <img src = "assets/pregnancycare.webp">
                        <div class="pregpara">
                            <h1>Pregnancy Care</h1>
                            <h2>Tips for health Pregnancy </h2>
                            <p>Learn about prenanral checkup,healthy habits nutrition and important precautions during pregnancy </p>
                             <a href="javascript:">
                        <button class="readmorebutton">Read More -></button> </a>
                        </div>
                       
                    </div>
                </div> 
        </div>
</div>

    <div class="footercontainer">
        <div class="container">
            <div class="topfooter">
            <div class="innertopfooter">
                 <img src = "assets/logoImg.png" class="footerimage">
                    <div class="innertopfooter">
                        <div>
                                <div>
                                    <h1 class="paridhihead">Dr.paridhi Chaudhary</h1>
                                </div>
                         <div class="footerlogopara">
                            <p>obstetrician & gynaecologist Laparascopic 
                            <br> Surgeon and Infertility Spesialist </p>
                         </div>
                    </div>
            </div>
</div>
                  <div class="innerfootercontainer">
                        <div>
                            <h1 class="followuson"> Follow us on </h1>
                        </div>
                        <div class="socialicon">
                            <a href="javascript:" aria-label="YouTube"><i class="bi bi-youtube socialiconimg socialicon-youtube"></i></a>
                            <a href="javascript:" aria-label="Instagram"><i class="bi bi-instagram socialiconimg socialicon-instagram"></i></a>
                            <a href="javascript:" aria-label="Facebook"><i class="bi bi-facebook socialiconimg socialicon-facebook"></i></a>
                        </div>
                    </div>

        


        </div>

    </div>
<hr class="hr">
<div class="downfooter">
    <div class=container>
        <div class="bottomfooter">
                        <div class="footeraboutus">
                            <h1 class="footerhead">About Us</h1>
                            <p>Dr.Paridhi Chaudhary beleives Objstetrics & gynaecological is an
                                important and sensitives filed of medicine that require dedication 
                                empathy and compassion , Every woman deserves to be heared understood and treated with respect 
                            </p>
                        </div>
                                <div>
                                    <h1 class="footerhead">Contact info</h1>
                                <div class="footermain">
                                    <div class="locationflex">
                                    <div>
                                    <i class="bi bi-geo-alt-fill locationicon"></i>
                                    </div>
                                    <div>
                                    <h2 >Address</h2>
                                    <p>Shop No,6,7,RPG Galleria GP Pocket,Ganga Nagar, Meerut,Uttar Pradesh-250001</p>
                                    </div>
                                    </div>
                                    
                                    <div class="locationflex">
                                    <div>
                                    <i class="bi bi-telephone-fill locationicon"></i>
                                    </div>
                                    <div>
                                    <h2>Phone no </h2>
                                       <p>+91-9286197331, 01214567142</p>
                                     </div>
                                     </div>
                                 
                                    <div class="locationflex">
                                    <div>
                                     <i class="bi bi-envelope-fill locationicon"></i>
                                    </div>
                                    <div>
                                    <h2> Email:</h2>
                                     <p>Drparidhichaudhary@gmail.com </p>
                                    </div>
                                    </div>
                                
                                    
                                </div>
                                </div>
                                <div class="otherpages">
                                   
                                    <h1 class="footerhead">Other Pages </h1>
                                    <ul>
                                        <li>Home</li>
                                        <li>About Us</li>
                                        <li>Soecialities</li>
                                        <li>Blogs</li>
                                        <li>Gallery</li>
                                    </ul>
                                  
                                </div>
                                <div class="otherpages">
                                    <h1 class="footerhead">Our Services</h1>
                                    <ul>
                                        <li>Attenantal Screening,Pregnancy Treatment including high risk pregnancy</li>
                                        <li> Delivery-Normal and C-Section</li>
                                        <li>Infertiity Problem </li>
                                        <li>Period Related Problem </li>
                                    </ul>
                                </div>
    </div>


    </div>
</div>
</div>
<div class="footerstrip">
    <p>© 2026 Dr. Paridhi Chaudhary. All Rights Reserved.</p>
    <div>
        Designed & Developed by <a href="https://promotionparadise.in/"> Promotion Paradise</a>
    </div>
</div>
  <a href="javascript:" class="btn btn-success">
    <i class="fa fa-whatsapp"></i>
  </a>


  <a href="tel:+1234567890" class="btn btn-primary">
    <i class="fa fa-phone"></i>
  </a>

</body>
