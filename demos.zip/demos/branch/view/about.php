<div class="about-section">
    <div class="aboutcontainer">
        <div class="container">
              <div class="aboutinner">
                        <div class="abouttext paragraphheading">
                                <h1 class="tagheading">Dr Paridhi Chaudhary</h1>
                                <h2>Meet Our Gynaecologist in Meerut <br>MBBS,MS,DNB</h2>
                                <p>I believe Obstetrics & Gynecology is an important and sensitive field of medicine that requires dedication, empathy, and compassion. Every woman deserves to be heard, understood, and treated with respect. My goal is to provide a comfortable environment where patients can openly discuss their concerns and receive personalized care according to their needs.</p>
                                <p>My approach focuses on supporting women through every stage of life, from routine gynecological care and pregnancy to reproductive health and menopause. I strive to provide clear guidance, compassionate support, and quality medical care while helping every patient make informed decisions about her health and well-being.</p>
                            <div class="aboutbuttoncontainer">
                                <button class="aboutbutton">Know More</button>
                                <a href="javascript:">Helpline ! : +91-9286197331, 01214567142</a>
                            </div>
                                      
                        </div>
                        
                            <div class="aboutimage">
                                <img src="assets/drparidhiaboutus.webp">
                            </div>
                 </div>
            </div>
    </div> 
</div>  