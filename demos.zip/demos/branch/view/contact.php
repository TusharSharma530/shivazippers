<div>
        <div class="container">
            <div class="contactcontainer">
                <div class="emlflp">

                    <div class="contactdetails">
                        <h1 class="clini">Clinic</h1>

                        <div class="contacttele">
                            <div class="contacticon">
                                <i class="bi bi-telephone"></i>
                            </div>
                            <div>
                                <h1>Call now</h1>
                                <p>+91-9286197331 , +91-01214567142</p>
                            </div>
                        </div>

                        <div class="contctemil">
                            <div class="contacticon">
                                <i class="bi bi-envelope"></i>
                            </div>
                            <div>
                                <h1>Email</h1>
                                <p>drparidhichaudhary@gmail.com</p>
                            </div>
                        </div>

                        <div class="contctemil">
                            <div class="contacticon">
                                <i class="bi bi-geo-alt"></i>
                            </div>
                            <div>
                                <h1>Address</h1>
                                <p>Shop No,6,7,RPG Galleria GP Pocket,Ganga Nagar, Meerut,Uttar Pradesh-250001</p>
                            </div>
                        </div>

                        <div class="contctemil">
                            <div class="contacticon">
                                <i class="bi bi-clock"></i>
                            </div>
                            <div>
                                <h1>Timings</h1>
                                <p>11:00 AM – 8:00 PM ( sunday closed)</p>
                            </div>
                        </div>

                        <button class="aboutbutton contactbtn">Clinic</button>

                        <div class="contactmap">
                            <iframe src="https://maps.google.com/maps?q=RPG%20Galleria%20Ganga%20Nagar%20Meerut&t=&z=15&ie=UTF8&iwloc=&output=embed" loading="lazy"></iframe>
                            <a class="openmaps" href="https://maps.google.com/?q=RPG+Galleria+Ganga+Nagar+Meerut" target="_blank">Open in Maps <i class="bi bi-box-arrow-up-right"></i></a>
                        </div>
                    </div>

                    <div class="contactform">
                        <form>
                            <div class="formgroup">
                                <label>Full Name</label>
                                <div class="forminput">
                                    <i class="bi bi-person"></i>
                                    <input type="text" name="name" placeholder="Your Name">
                                </div>
                            </div>

                            <div class="formgroup">
                                <label>Email Address</label>
                                <div class="forminput">
                                    <i class="bi bi-envelope"></i>
                                    <input type="email" name="email" placeholder="Your Email">
                                </div>
                            </div>

                            <div class="formgroup">
                                <label>Phone Number</label>
                                <div class="forminput">
                                    <i class="bi bi-telephone"></i>
                                    <input type="tel" name="phone" placeholder="10-digit mobile number" maxlength="10">
                                </div>
                            </div>

                            <div class="formgroup">
                                <label>Message</label>
                                <div class="forminput">
                                    <i class="bi bi-chat-dots"></i>
                                    <textarea name="message" placeholder="Message"></textarea>
                                </div>
                            </div>

                            <button class="submitbtn" type="submit">Submit</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
</div>
