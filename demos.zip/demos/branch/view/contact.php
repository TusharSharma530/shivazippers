<div>
        <div class="container">
            <div class="contactcontainer">
            <h1 class="clini">clinics</h1>
            <div class="contacttele">
                <div>
                 <i class="bi bi-telephone"></i>
                </div>
                <div>
                <h1>Call Now</h1>
                <p>+91-9286197331 , +91-01214567142</p>
                </div>
            </div>
            <div class="contctemil">
                <div >
                     <div>
                     <i class="bi bi-envelope"></i>
                      </div>
                      <div>
                    <h1>E-mail</h1>
                    <p>drparidhi@gmail.com</p>
                    </div>
                <div>
                <div class="contctemil">
                    <div>
                    <i class="bi bi-geo-alt-fill"></i>
                     </div>
                     <div>
                    <h1>Address</h1>
                    <p>Shop No,6,7,RPG Galleria GP Pocket,Ganga Nagar, Meerut,Uttar Pradesh-250001</p>
                     </div>
                </div>
                <div class="contctemil">
                    <div>
                    <i class="bi bi-clock"></i>
                    </div>
                    <div>
                    <h1>Timings</h1>
                    <p>11:00 AM – 8:00 PM ( sunday closed)</p>
                    </div>
                </div> 
                <button>Clinics</button>    
</div>   
        </div>
</div>