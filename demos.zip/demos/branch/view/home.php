
<div class="banner-section">
    
        <div class="slider" data-slides-desktop="1" data-slides-mobile="1">
            <img src="assets/drparidhi.webp">
            <img src="assets/banner6.webp">
            <img src="assets/banner5.webp">
            <img src="assets/banner4.webp">
        </div>
   
</div>
                     <a href="tel:9286197331">
                    <div class="appointbtn emergencybutton ">
                       
                        <button class="submitbtn emerbut"> Emergency <i class="bi bi-telephone "></i></button>
                    </div>
</a>

<div class="about-section">
    <div class="aboutcontainer">
        <div class="container">
              <div class="aboutinner">
                        <div class="abouttext paragraphheading">
                                <h1 class="tagheading">Dr Paridhi Chaudhary</h1>
                                <h2>Meet Our Gynaecologist in Meerut <br>MBBS,MS,DNB</h2>
                                <p>I believe Obstetrics & Gynecology is an important and sensitive field of medicine that requires dedication, empathy, and compassion. Every woman deserves to be heard, understood, and treated with respect. My goal is to provide a comfortable environment where patients can openly discuss their concerns and receive personalized care according to their needs.</p>
                                <p>My approach focuses on supporting women through every stage of life, from routine gynecological care and pregnancy to reproductive health and menopause. I strive to provide clear guidance, compassionate support, and quality medical care while helping every patient make informed decisions about her health and well-being.</p>
                            <div class="aboutbuttoncontainer">
                                <button class="aboutbutton">Know More</button>
                                <a href="javascript:">Helpline ! : +91-9286197331, 01214567142</a>
                            </div>
                                      
                        </div>
                        
                            <div class="aboutimage">
                                <img src="assets/drparidhiaboutus.webp">
                            </div>
                 </div>
            </div>
    </div> 
</div>    

<div class="servicesection">
    <div class="container">
        <div class="serviceinner paragraphheading">
            <h1 class="serviceheading tagheading">Condition We Treat</h1>
            <h2>Conditions Treated By Dr.Paridhi Chaudhary - Gynaecologist in Meerut</h2>
        </div>
        <div class="slider servicecardcontainer" data-slides-desktop="4" data-slides-mobile="1">
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/periodrelated.webp">
                </figure>
                <h3>Pregnancy Care</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Infertility Problem</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Period related problem</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Cancer Screening</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/periodrelated.webp" class="servicecardimg">
                </figure>
                <h3>Laparascopic</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            
            
</div>  
    </div>
</div>
<div class="gallery-section">
    <div class="container">
        <div class="headgallery paragraphheading">
                <h1 class="gallerytag tagheading">Our Clinic </h1>
                <h2 class="galleryhead ">Gallery</h2>
        </div>
        <div class="gallerycontainer">
            <div class="slider galeryimg"data-slides-desktop="4" data-slides-mobile="1">
          
                <img src="assets/galleryimage.jpeg">
                <img src="assets/galleryimage2.jpeg">
                <img src="assets/galleryimage3.jpeg">
                <img src="assets/galleryimage4.jpeg">
         
            </div>    
        </div>
    </div>
</div>

<div class="mycommitmentsection">
    <div class="container">
     <div class="innercontainer">
        <div>
            <img src = "assets/commitment.png">
        </div>
            <div class="commitmentinnerpara paragraphheading">
                <h1 class="tagheading"> My Commitment </h1>
                <h2>Commitment To Every Patient's Health & Well-Being </h2>
                <p>I am committed to providing compassionate, ethical, and evidence-based gynecological care to every woman who walks into my clinic. From routine consultations to complex treatments, every patient receives complete attention, clear guidance, and honest advice at every step.</p>
                <p>.My priority is to build a comfortable and trusting relationship where women can openly discuss their health concerns without hesitation and receive personalized care that suits their individual needs and stage of life.</p>
            </div>
            
        </div>
</div>
    </div>
</div>

<div class=bookappointmentcontainer>
    <div class="container">
    <h1 class = "bookhead"> Facing Gynae Concerns? Get Expert Help From <br> Dr. Paridhi Chaudhary </h1>
            <div class="callus">
                        <div class="callinner sectionpara">
                            <div>
                                <i class="bi bi-telephone bookicon"></i>
                             </div>
                             <div>
                                <a href="javascript:">
                                <h1 class="head"> Call Us :</h1>
                                <p>+91-9286197331 , 01214567142</p>
                               </a>
                              </div>   
                        </div>
                        <div class="callinneremail sectionpara">
                            <div>
                                 <i class="bi bi-envelope-fill bookicon"></i>
                                
                            </div>
                               <div>
                                <a href="javascript:">
                                <h1 class="head"> E-mail Us :</h1>
                                <p>drparidhichaudhary@gmail.com</p> </a>
                               </div>
                        </div>
               
                        <div class="visitus sectionpara">
                            <div>
                                <i class="bi bi-geo-alt bookicon"></i>
                             </div>
                             <div>
                            <h1 class="head">Visit Us :</h1>
                            <p>Shop No,6,7,RPG Galleria GP Pocket,Ganga Nagar, <br>Meerut,Uttar Pradesh-250001</p>
                           </div>
                        </div>
                   <a href="javascript:"> <button class="bookbtn">Book an Appointment</button></a>
        </div>
    </div>
</div>

    <div class="symptomscontainer">
        <div class="container">
            <div class="paragraphheading">
            <h1 class="tagheading symtag">Symptoms</h1>
            <h2 class="symptoms">
                What are the Symptoms of Gynaecological Diseases
            </h2>
            <p class="symptomsintro">
                Gynecological conditions can often go unnoticed in the early stages. Recognizing the warning signs early is key to timely diagnosis and effective treatment. If you're experiencing any of the following symptoms, it may indicate an underlying gynecological issue:
            </p>
          </div>
            
            <div class="litags">  
                       <ul class= "symplomeli">
                            <li>
                                Missed menstrual period
                            </li>
                            <li>
                               Irregular Period
                            </li>
                           
                             <li>
                                Pain or discomfort during intercourse
                            </li>
                             <li>
                                Vaginal Itching
                            </li>
                             <li>
                                Heavy menstrual bleeding
                            </li>
                             <li>
                                Pain or pressure in your Pelvis <br>that differ from menstrual cramps
                            </li> 
                            <li>
                                Excessive bloating
                           </li>
                           <li>
                            Breast Changes
                           </li>

                        </ul>   
            </div>
        
        </div>
    </div>    
<div class="testinomialcontainer">
        <div class="container">
            <div >
           <div class="paragraphheading">
            <h1 class="tagheading testimon">Testimonials</h1>
            <h2 class="symptoms tagheading">what our patents says about us </h2>
            <p class="serviceheadingh2">Experience shared by patents about their core and consultation with dr paridhi chaudhary </p>
            </div>
            <div class="testinomialcards slider"data-slides-desktop="3" data-slides-mobile="3">
              <div class="testinomialinner ">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Excellent </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
              <div class="testinomialinner">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Caring </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
               <div class="testinomialinner">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Smart </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
              <div class="testinomialinner">
                <p>⭐⭐ ⭐⭐ ⭐</p>
                <h1>Very Caring </h1>
                <p>Dr paridhy chaudhary ia a highly , professional,caring and approachable she
                takes times to understand patents concerns and provide clear guidance ,making every
                consultation reassuring and comfortable
                </p>
              </div>
            </div>
</div>
        </div>
</div>
<div class="latestblogcontainer">
            <div class="container">
                <div class="paragraphheading">
                    <h1 class="tagheading article">Health Article </h1>
                    <h2 class="serviceheadingh2">Latest Blogs</h2>
                    <p class="blogpara"> Explore helpful information ,expert guidance , women's healthcare tips from
                        dr paridhary .
                    </p>
                </div>
                <div class="slider "data-slides-desktop="3" data-slides-mobile="3">
                    <div class="blogscontainer">
                        <img src = "assets/pregnancycare.webp">
                        <div class="pregpara">
                            <h1>Pregnancy Care</h1>
                            <h2>Tips for health Pregnancy </h2>
                            <p>Learn about prenanral checkup,healthy habits nutrition and important precautions during pregnancy </p>
                             <a href="javascript:">
                        <button class="readmorebutton">Read More -></button></a>
                        </div>
    
                    </div>
                    <div class="blogscontainer">
                        <img src = "assets/pregnancycare.webp">
                        <div class="pregpara">
                            <h1 >Pregnancy Care</h1>
                            <h2 >Tips for health Pregnancy </h2>
                            <p >Learn about prenanral checkup,healthy habits nutrition and important precautions during pregnancy </p>
                             <a href="javascript:">
                        <button class="readmorebutton">Read More -></button></a>
                        </div>
                       
                    </div>
                    <div class="blogscontainer">
                        <img src = "assets/pregnancycare.webp">
                        <div class="pregpara">
                            <h1>Pregnancy Care</h1>
                            <h2>Tips for health Pregnancy </h2>
                            <p>Learn about prenanral checkup,healthy habits nutrition and important precautions during pregnancy </p>
                             <a href="javascript:">
                        <button class="readmorebutton">Read More -></button> </a>
                        </div>
                       
                    </div>
                </div> 
        </div>
</div>

    
  <div class="floating-actions">
    <a href="javascript:" class="floating-btn whatsapp-btn" aria-label="Chat on WhatsApp">
      <i class="fa fa-whatsapp"></i>
    </a>

    <a href="tel:+1234567890" class="floating-btn call-btn" aria-label="Call us">
      <i class="fa fa-phone"></i>
    </a>
  </div>

  <a href="#" class="floating-btn totop-btn" id="totopBtn" aria-label="Back to top">
    <i class="fa fa-arrow-up"></i>
  </a>
