<div class="footercontainer">
        <div class="container">
            <div class="topfooter">
            <div class="innertopfooter">
                 <img src = "assets/logoImg.png" class="footerimage">
                    <div class="innertopfooter">
                        <div>
                                <div>
                                    <h1 class="paridhihead">Dr.paridhi Chaudhary</h1>
                                </div>
                         <div class="footerlogopara">
                            <p>obstetrician & gynaecologist Laparascopic 
                            <br> Surgeon and Infertility Spesialist </p>
                         </div>
                    </div>
            </div>
</div>
                  <div class="innerfootercontainer">
                        <div>
                            <h1 class="followuson"> Follow us on </h1>
                        </div>
                        <div class="socialicon">
                            <a href="javascript:" aria-label="YouTube"><i class="bi bi-youtube socialiconimg socialicon-youtube"></i></a>
                            <a href="javascript:" aria-label="Instagram"><i class="bi bi-instagram socialiconimg socialicon-instagram"></i></a>
                            <a href="javascript:" aria-label="Facebook"><i class="bi bi-facebook socialiconimg socialicon-facebook"></i></a>
                        </div>
                    </div>

        


        </div>

    </div>
<hr class="hr">
<div class="downfooter">
    <div class=container>
        <div class="bottomfooter">
                        <div class="footeraboutus">
                            <h1 class="footerhead">About Us</h1>
                            <p>Dr.Paridhi Chaudhary beleives Objstetrics & gynaecological is an
                                important and sensitives filed of medicine that require dedication 
                                empathy and compassion , Every woman deserves to be heared understood and treated with respect 
                            </p>
                        </div>
                                <div>
                                    <h1 class="footerhead">Contact info</h1>
                                <div class="footermain">
                                    <div class="locationflex">
                                    <div>
                                    <i class="bi bi-geo-alt-fill locationicon"></i>
                                    </div>
                                    <div>
                                    <h2 >Address</h2>
                                    <p>Shop No,6,7,RPG Galleria GP Pocket,Ganga Nagar, Meerut,Uttar Pradesh-250001</p>
                                    </div>
                                    </div>
                                    
                                    <div class="locationflex">
                                    <div>
                                    <i class="bi bi-telephone-fill locationicon"></i>
                                    </div>
                                    <div>
                                    <h2>Phone no </h2>
                                       <p>+91-9286197331,</p>
                                       <br>
                                        <p>01214567142 </p>
                                     </div>
                                     </div>
                                 
                                    <div class="locationflex">
                                    <div>
                                     <i class="bi bi-envelope-fill locationicon"></i>
                                    </div>
                                    <div>
                                    <h2> Email:</h2>
                                     <p>Drparidhichaudhary@gmail.com </p>
                                    </div>
                                    </div>
                                
                                    
                                </div>
                                </div>
                                <div class="otherpages">
                                   
                                    <h1 class="footerhead">Other Pages </h1>
                                    <ul>
                                        <li>Home</li>
                                        <li>About Us</li>
                                        <li>Soecialities</li>
                                        <li>Blogs</li>
                                        <li>Gallery</li>
                                    </ul>
                                  
                                </div>
                                <div class="otherpages">
                                    <h1 class="footerhead">Our Services</h1>
                                    <ul>
                                        <li>Attenantal Screening,Pregnancy Treatment including high risk pregnancy</li>
                                        <li> Delivery-Normal and C-Section</li>
                                        <li>Infertiity Problem </li>
                                        <li>Period Related Problem </li>
                                    </ul>
                                </div>
    </div>


    </div>
</div>
</div>
<div class="footerstrip">
    <p>© 2026 Dr. Paridhi Chaudhary. All Rights Reserved.</p>
    <div>
        Designed & Developed by <a href="https://promotionparadise.in/"> Promotion Paradise</a>
    </div>
</div>