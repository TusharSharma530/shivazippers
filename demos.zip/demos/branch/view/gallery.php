<div class="gallery-section">
    <div class="container">
        <div class="headgallery paragraphheading">
                <h1 class="gallerytag tagheading">Our Clinic </h1>
                <h2 class="galleryhead ">Gallery</h2>
        </div>
        <div class="gallerycontainer">
            <div class="slider galeryimg"data-slides-desktop="4" data-slides-mobile="1">
          
                <img src="assets/galleryimage.jpeg">
                <img src="assets/galleryimage2.jpeg">
                <img src="assets/galleryimage3.jpeg">
                <img src="assets/galleryimage4.jpeg">
         
            </div>    
        </div>
    </div>
</div>