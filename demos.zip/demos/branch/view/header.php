<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
     <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
     <link rel="stylesheet" href="slick/slick.css">
    <link rel="stylesheet" href="slick/slick-theme.css">
    <link href="style.css" rel="stylesheet">
    <script src="slick/slick.min.js" defer></script>
    <script src="js/script.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<div class="headerpart">
    <div class="container">
    <div class="topcontainer">   
    
        <div class="logo-section">
                <div class="logo-section">
                    <!-- <a href="javascript:"> -->
                 <a href="javascript:">   <img src="assets/logoimg.png"> </a>
                    <div class="text-section">
                       <a href="javascript:"> <h1>Dr. Paridhi Chaudhary</h1> 

                        <p>
                            Obstetrician & Gynecologist, Laparoscopic
                            <br>
                            Surgeon and Infertility Specialist
                        </p>
                     </a>
                    </div>

                </div>
        </div>

        <div class="contact-section">
                    <div class="contact-image">
                        <div class="contact-imageinner">
                                <i class="bi bi-envelope headericon"></i>
                        </div>
                        <div class="contact-text">
                          <a href="mailto:drparidhichaudhary@gmail.com">  <span class="contact-label">  Mail Us</span> 
                            <p>drparidhichaudhary@gmail.com</p> </a>
                        </div>
                    </div>
                    <div class="contact-heading">
                        <div class="contact-imageinnerphone">
                                <i class="bi bi-telephone headericon"></i>
                         </div>
                         <div class="contact-text">
                        <span class="contact-labelcontact">Contact Us</span>
                        <a href="tel:9286197331">
                            <p> +91-9286197331,</a>
                             <br>  <a href="tel:01214567142"> +91-01214567142</p> </a>
                         </div>
                        
                          <div class="emergenctbutton ">
                        <button class="submitbtn emergencybtn blink">24*7 Available <br> for pregnant ladies</button>
                    </div>
              
                       
                    </div>
                </div>
    </div>  

</div>
</div>

</div>

<div class="header">
    <div class="headercontainer">
        
            <div class="container">
                <div class =" headerconti">
                    <div class="headerinner">
                        <a href="<?=$path;?>home"> Home</a>
                   
                        
                            <a href="<?=$path;?>about"> About</a>
                            <a href="<?=$path?>service"> Services</a>
                        <a href="<?=$path?>gallery"> Gallery</a>
                        <a href="<?=$path?>contact"> Contact</a>
                    </div>
                    <div class="appointbtn">
                        <button class="submitbtn">Book An Appointment</button>
                    </div>
                </div>    
             </div>
    </div>
</div>