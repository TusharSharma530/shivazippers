
<div class="servicesection">
    <div class="container">
        <div class="serviceinner paragraphheading">
            <h1 class="serviceheading tagheading">Condition We Treat</h1>
            <h2>Conditions Treated By Dr.Paridhi Chaudhary - Gynaecologist in Meerut</h2>
        </div>
        <div class="servicecardcontainer">
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/periodrelated.webp">
                </figure>
                <h3>Pregnancy Care</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Infertility Problem</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Period related problem</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/cancerscreening.webp">
                </figure>
                <h3>Cancer Screening</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></button>
            </div>
            <div class="servicecard tagheading paragraphheading">
                <figure>
                    <img src="assets/periodrelated.webp" class="servicecardimg">
                </figure>
                <h3>Laparascopic</h3>
                <p>Early detection and screening for various gynecological cancers, ensuring timely intervention and better outcomes.</p>
                <button>Read More -></butston>
            </div>
            
            
</div>  
    </div>
</div>