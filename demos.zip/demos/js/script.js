 document.addEventListener('DOMContentLoaded', function () {
 if (window.jQuery && jQuery.fn.slick) {

           if (window.jQuery && jQuery.fn.slick) {

        jQuery('.slider').each(function () {

            const $el = jQuery(this);

            $el.slick({
                slidesToShow: parseInt($el.attr('data-slides-desktop'), 10) || 1,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2500,
                dots: false,
                arrows: true,
                infinite: true,
                speed: 900,
                responsive: [{
                    breakpoint: 992,
                    settings: {
                        slidesToShow: parseInt($el.attr('data-slides-mobile'), 10) || 1
                    }
                }]
            });

        });
    }
    }
    });

  const toTopBtn = document.getElementById('totopBtn');
  if (toTopBtn) {
    const toggleToTop = function () {
      toTopBtn.classList.toggle('show', window.scrollY > 300);
    };
    toggleToTop();
    window.addEventListener('scroll', toggleToTop, { passive: true });

    toTopBtn.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // headerpart ki height menu bar ke liye
  const headerpart = document.querySelector('.headerpart');
  const setHeaderHeight = function () {
    if (headerpart) {
      document.documentElement.style.setProperty('--headerh', headerpart.offsetHeight + 'px');
    }
  };
  setHeaderHeight();
  window.addEventListener('resize', setHeaderHeight);